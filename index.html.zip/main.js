<!DOCTYPE html>

<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>Hello, World!</title>
</head>
<body>
  <h1>
    <b>
      
      <i> <font color=" red"> 
        WELCOME TO DOCTOR G.M PANHWER INSTITUTE OF KNOWLEDGE LEARNING AND SKILLS </h1>
        </b></font> 
       
      
      
      
<h2>
 
   
  <small>CREDIT TO MOST HONOURABLE TEACHERS&#x2193;&#x2193;&#x2193;
  </h3>
  <big>
    <b>                                    </h2> </small>
<br>
  1&#9829;&#x21a3;  <i>SIR PREM KUMAR</i>  <br>
  2&#9829;&#x21a3; <i>SIR SADAM NOHRI</i> <br> 
  2&#9829;&#x21a3; <i> SIR NIHAL KUMAR</i> <br>
  3&#9829;&#x21a3; <i> SIR AFTAB AHMED ENGLISH EXPERT</i> <br>
  4&#9829;&#x21a3;<i> SIR RIAZ AHMED MARI</i> <br>
 </pre> 5&#9829;&#x21a3; <i>SIR SHAHID MARI  </i> <br>

</h3>

</big></b>


<pre>


</pre>
<h4>
<big>
   <b>
       WHAT IS DOCTOR sG.M PANHWER INSTITUTE??
   </b>
  
  </big>
</h4>
<p>
 
The Doctor G.M. Panhwer Institute of Learning and Skills is a premier educational institution renowned for its commitment to academic excellence and innovation. <br>With a focus on providing top-notch education and training in various fields, the institute has established itself as a hub for students seeking to enhance their knowledge and skills.

  <img src="lab.jpg" alt="no"> width="20.PX"
</body>
</html>


